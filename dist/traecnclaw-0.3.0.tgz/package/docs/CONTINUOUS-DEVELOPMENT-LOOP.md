# Continuous Development Loop State

This file is the durable handoff state for the recurring Codex development
loop. Every scheduled development run must read it before choosing work and
update it before finishing.

## Update Rules

- Read this file before selecting the run objective.
- Update `Active Run` at the start of each run with the selected objective.
- Append one concise `Run Log` entry before the run finishes.
- Update `Current Focus`, `Priority Backlog`, and `Next Recommended Work` when
  new evidence changes the plan.
- Record verification commands and results, including failures or skips.
- Record commit hashes when the automation creates a commit.
- Keep entries short enough to be useful as context. Prefer facts over status
  prose.
- Do not store secrets, tokens, raw TraeCN profile data, logs, or local output.

## Product Direction

TRAECNclaw should become a reliable TraeCN automation gateway, MCP server, and
OpenClaw integration that any AI agent can use through a simple developer
interface. The project is still considered incomplete. Large changes are
acceptable when they produce a coherent, verified improvement.

## Automation Contract

- Automation name: `TRAECNclaw continuous development loop`
- Schedule: hourly, starting from 2026-07-04 14:00 Asia/Shanghai
- Model posture: high-effort recurring development in an isolated worktree
- Default safety boundary: no real TraeCN task submission, quota spend, push, or
  external UI operation without explicit user approval
- Expected output per run: code/docs/tests improvement, verification evidence,
  durable state update, and optionally a conventional commit in the automation
  worktree

## Current Focus

Build compounding product maturity around:

- real agent-facing APIs and low-friction developer entrypoints
- executable MCP and OpenClaw surfaces
- gateway readiness, recovery, and diagnostics
- dialog and task-state recovery
- unattended workflow acceptance evidence
- queue cleanup reliability
- deterministic prompt layers and live/mock parity
- tests and documentation for installation, configuration, API behavior, and
  workflows

## Priority Backlog

1. Verify that public agent entrypoints remain executable and documented:
   simple API, HTTP gateway, MCP server, CLI, and OpenClaw plugin.
2. Strengthen unattended acceptance coverage so failures explain the missing
   evidence instead of reporting generic incomplete status.
3. Improve gateway recovery paths around stale processes, disconnected CDP, and
   readiness blockers.
4. Improve queue cleanup and long-queue status reporting without submitting live
   prompts or spending quota by default.
5. Keep OpenAPI, README, development docs, and plugin command docs synchronized
   with implementation behavior.
6. Expand tests for changed behavior using the existing plain Node test style.

## Active Run

- Status: idle
- Objective: none
- Started: none
- Notes: next automation run should choose from `Priority Backlog` unless new
  repo evidence points to a higher-value target.

## Next Recommended Work

Run a repo orientation pass, then choose one substantial objective from
`Priority Backlog`. Prefer a change that improves executable agent interfaces or
verification quality over cosmetic documentation edits.

## Run Log

### 2026-07-05 - Seed continuous development state

- Objective: create a versioned state file for the recurring development loop.
- Change: added this durable context file and update protocol.
- Verification: `git diff --check` passed; automation configuration now
  references this file as mandatory durable context.
- Commit: none yet.
- Next: run a repo orientation pass and choose the first substantial objective
  from `Priority Backlog`.

## Run Log Entry Template

```md
### YYYY-MM-DD - short objective

- Objective:
- Why it mattered:
- Files changed:
- Verification:
- Commit:
- Remaining risk:
- Next:
```
